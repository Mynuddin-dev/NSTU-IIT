package SE3110_Question1;

public class StudentInfo{

	String Name;
	String Roll;
	
	public void printInfo() {
		// write code for print student's info like name & roll
		System.out.println(Name+ " "+Roll);
	}
}
