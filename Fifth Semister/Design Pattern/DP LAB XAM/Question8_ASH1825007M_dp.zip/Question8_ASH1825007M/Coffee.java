/*
Name: Md Mynuddin
Roll No: ASH1825007M
Email: dp@mynuddin2513@student.edu.nstu.bd#2021
Date: 22/9/2021

 */
package SE3110_Question8;

/**
 * @author Mynuddin
 * 
 */
public class Coffee extends PrepareRecipe{
       
        public void brewCoffeeGrinds(){
            
        }
        
        public void addSugarAndMilk(){
            
        }
}
//dp@mynuddin2513@student.edu.nstu.bd#2021