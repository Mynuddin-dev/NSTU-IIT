
package SE3110_Question8;

public class PrepareRecipe {
    
    public void boilWater(){
           
       }
    public void PourIncup(){
           
       }
}
