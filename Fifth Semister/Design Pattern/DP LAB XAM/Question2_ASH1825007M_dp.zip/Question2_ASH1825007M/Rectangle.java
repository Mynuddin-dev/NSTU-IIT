package SE3110_Question2;

public class Rectangle {

	int a,b=0;
	
//	public double calculateArea(Object shape) {
//	     double area = 0;
//	     if (shape instanceof Square) {
//	         Square square = (Square) shape;
//	         area = square.getA() * square.getA();
//	     }
//	     else if (shape instanceof Rectangle) {
//	         Rectangle rectangle = (Rectangle) shape;
//	         area = rectangle.getA() * rectangle.getB();
//	     }
//	     else if (shape instanceof Circle) {
//	         Circle circle = (Circle) shape;
//	         area = Math.PI * circle.getR() * circle.getR();
//	     }
//	     return area;
//	} Code Duplication

	int getB() {
		// TODO Auto-generated method stub
		return b;
	}

	public int getA() {
		// TODO Auto-generated method stub
		return a;
	}

}
